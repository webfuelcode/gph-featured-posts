jQuery(document).ready(function($) {
    
    // Initialize featured posts slider
    function initFeaturedPostsSlider() {
        $('.gph-featured-posts-slider').each(function() {
            var $slider = $(this);
            var $wrapper = $slider.find('.featured-posts-wrapper');
            var $slides = $wrapper.find('.featured-post-slide');
            var $prevBtn = $slider.find('.slider-nav.prev');
            var $nextBtn = $slider.find('.slider-nav.next');
            
            if ($slides.length === 0) {
                return;
            }
            
            var currentIndex = 0;
            var slideWidth = $slides.outerWidth(true);
            var visibleSlides = Math.floor($slider.width() / slideWidth);
            var maxIndex = Math.max(0, $slides.length - visibleSlides);
            
            // Update slider position
            function updateSlider() {
                var translateX = -(currentIndex * slideWidth);
                $wrapper.css('transform', 'translateX(' + translateX + 'px)');
                
                // Update navigation button states
                $prevBtn.prop('disabled', currentIndex === 0);
                $nextBtn.prop('disabled', currentIndex >= maxIndex);
            }
            
            // Navigate to specific slide
            function goToSlide(index) {
                currentIndex = Math.max(0, Math.min(index, maxIndex));
                updateSlider();
            }
            
            // Previous slide
            $prevBtn.on('click', function() {
                if (currentIndex > 0) {
                    goToSlide(currentIndex - 1);
                }
            });
            
            // Next slide
            $nextBtn.on('click', function() {
                if (currentIndex < maxIndex) {
                    goToSlide(currentIndex + 1);
                }
            });
            
            // Handle window resize
            function handleResize() {
                slideWidth = $slides.outerWidth(true);
                visibleSlides = Math.floor($slider.width() / slideWidth);
                maxIndex = Math.max(0, $slides.length - visibleSlides);
                
                // Adjust current index if needed
                if (currentIndex > maxIndex) {
                    currentIndex = maxIndex;
                }
                
                updateSlider();
            }
            
            // Debounced resize handler
            var resizeTimer;
            $(window).on('resize', function() {
                clearTimeout(resizeTimer);
                resizeTimer = setTimeout(handleResize, 250);
            });
            
            // Touch/swipe support for mobile
            var startX = 0;
            var startY = 0;
            var isDragging = false;
            var threshold = 50; // Minimum distance for swipe
            
            $wrapper.on('touchstart mousedown', function(e) {
                e.preventDefault();
                isDragging = true;
                
                var clientX = e.type === 'mousedown' ? e.clientX : e.originalEvent.touches[0].clientX;
                var clientY = e.type === 'mousedown' ? e.clientY : e.originalEvent.touches[0].clientY;
                
                startX = clientX;
                startY = clientY;
                
                $wrapper.css('transition', 'none');
            });
            
            $(document).on('touchmove mousemove', function(e) {
                if (!isDragging) return;
                
                var clientX = e.type === 'mousemove' ? e.clientX : e.originalEvent.touches[0].clientX;
                var clientY = e.type === 'mousemove' ? e.clientY : e.originalEvent.touches[0].clientY;
                
                var deltaX = clientX - startX;
                var deltaY = clientY - startY;
                
                // Check if it's a horizontal swipe
                if (Math.abs(deltaX) > Math.abs(deltaY) && Math.abs(deltaX) > 10) {
                    e.preventDefault();
                }
            });
            
            $(document).on('touchend mouseup', function(e) {
                if (!isDragging) return;
                
                isDragging = false;
                $wrapper.css('transition', 'transform 0.4s ease-in-out');
                
                var clientX = e.type === 'mouseup' ? e.clientX : e.originalEvent.changedTouches[0].clientX;
                var deltaX = clientX - startX;
                
                if (Math.abs(deltaX) > threshold) {
                    if (deltaX > 0 && currentIndex > 0) {
                        // Swipe right - go to previous slide
                        goToSlide(currentIndex - 1);
                    } else if (deltaX < 0 && currentIndex < maxIndex) {
                        // Swipe left - go to next slide
                        goToSlide(currentIndex + 1);
                    }
                }
            });
            
            // Keyboard navigation
            $slider.on('keydown', function(e) {
                switch(e.which) {
                    case 37: // Left arrow
                        e.preventDefault();
                        if (currentIndex > 0) {
                            goToSlide(currentIndex - 1);
                        }
                        break;
                    case 39: // Right arrow
                        e.preventDefault();
                        if (currentIndex < maxIndex) {
                            goToSlide(currentIndex + 1);
                        }
                        break;
                }
            });
            
            // Make slider focusable for keyboard navigation
            $slider.attr('tabindex', '0');
            
            // Auto-play functionality (optional)
            var autoPlayInterval;
            var autoPlayDelay = 5000; // 5 seconds
            
            function startAutoPlay() {
                if ($slides.length <= visibleSlides) return;
                
                autoPlayInterval = setInterval(function() {
                    if (currentIndex >= maxIndex) {
                        goToSlide(0);
                    } else {
                        goToSlide(currentIndex + 1);
                    }
                }, autoPlayDelay);
            }
            
            function stopAutoPlay() {
                clearInterval(autoPlayInterval);
            }
            
            // Pause auto-play on hover
            $slider.on('mouseenter', stopAutoPlay);
            $slider.on('mouseleave', startAutoPlay);
            
            // Pause auto-play when slider is not visible
            function handleVisibilityChange() {
                if (document.hidden) {
                    stopAutoPlay();
                } else {
                    startAutoPlay();
                }
            }
            
            document.addEventListener('visibilitychange', handleVisibilityChange);
            
            // Initialize
            updateSlider();
            
            // Start auto-play if there are more slides than visible
            if ($slides.length > visibleSlides) {
                startAutoPlay();
            }
            
            // Add loading animation
            $slider.addClass('slider-initialized');
        });
    }
    
    // Initialize on page load
    initFeaturedPostsSlider();
    
    // Reinitialize when featured posts are dynamically inserted
    $(document).on('gph_featured_posts_inserted', function() {
        setTimeout(initFeaturedPostsSlider, 100);
    });
    
    // Reinitialize on AJAX content load (for themes that use AJAX)
    $(document).on('ajaxComplete', function() {
        setTimeout(initFeaturedPostsSlider, 100);
    });
});
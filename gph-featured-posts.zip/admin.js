jQuery(document).ready(function($) {
    
    // Make selected posts sortable
    $('#selected-posts').sortable({
        handle: '.drag-handle',
        placeholder: 'ui-sortable-placeholder',
        update: function(event, ui) {
            updateFeaturedPostsOrder();
        }
    });
    
    // Add post to featured
    $(document).on('click', '.add-post', function(e) {
        e.preventDefault();
        
        var postId = $(this).data('post-id');
        var postItem = $(this).closest('.post-item');
        var clonedItem = postItem.clone();
        
        // Update the cloned item for selected posts
        clonedItem.removeClass('available-post').addClass('selected-post');
        clonedItem.prepend('<span class="dashicons dashicons-menu drag-handle"></span>');
        clonedItem.find('.add-post').removeClass('add-post button-primary').addClass('remove-post').text('Remove');
        
        // Add to selected posts
        $('#selected-posts').append(clonedItem);
        
        // Remove from available posts
        postItem.remove();
        
        // Update order
        updateFeaturedPostsOrder();
    });
    
    // Remove post from featured
    $(document).on('click', '.remove-post', function(e) {
        e.preventDefault();
        
        var postId = $(this).data('post-id');
        var postItem = $(this).closest('.post-item');
        var clonedItem = postItem.clone();
        
        // Update the cloned item for available posts
        clonedItem.removeClass('selected-post').addClass('available-post');
        clonedItem.find('.drag-handle').remove();
        clonedItem.find('.remove-post').removeClass('remove-post').addClass('add-post button-primary').text('Add to Featured');
        
        // Add to available posts (sorted by date)
        var inserted = false;
        $('#available-posts .available-post').each(function() {
            var currentTitle = $(this).data('title');
            var newTitle = clonedItem.data('title');
            
            if (newTitle < currentTitle) {
                $(this).before(clonedItem);
                inserted = true;
                return false;
            }
        });
        
        if (!inserted) {
            $('#available-posts').append(clonedItem);
        }
        
        // Remove from selected posts
        postItem.remove();
        
        // Update order
        updateFeaturedPostsOrder();
        
        // Clear search if active
        var searchTerm = $('#posts-search').val().toLowerCase();
        if (searchTerm) {
            filterPosts(searchTerm);
        }
    });
    
    // Search functionality
    $('#posts-search').on('input', function() {
        var searchTerm = $(this).val().toLowerCase();
        filterPosts(searchTerm);
    });
    
    // Filter posts based on search term
    function filterPosts(searchTerm) {
        $('#available-posts .available-post').each(function() {
            var postTitle = $(this).data('title');
            
            if (postTitle.indexOf(searchTerm) !== -1) {
                $(this).show();
            } else {
                $(this).hide();
            }
        });
    }
    
    // Update the hidden input with featured posts order
    function updateFeaturedPostsOrder() {
        var postIds = [];
        
        $('#selected-posts .selected-post').each(function() {
            postIds.push($(this).data('post-id'));
        });
        
        $('#featured-posts-order').val(postIds.join(','));
    }
    
    // Show success message if present
    var urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('message') === 'saved') {
        // Create and show success notice
        var successNotice = $('<div class="notice notice-success is-dismissible"><p><strong>Featured posts saved successfully!</strong></p></div>');
        $('.wrap h1').after(successNotice);
        
        // Remove message parameter from URL
        var newUrl = window.location.pathname + '?page=gph-featured-posts';
        window.history.replaceState({}, '', newUrl);
    }
    
    // Handle dismiss button for notices
    $(document).on('click', '.notice-dismiss', function() {
        $(this).closest('.notice').remove();
    });
    
    // Initialize order on page load
    updateFeaturedPostsOrder();
});
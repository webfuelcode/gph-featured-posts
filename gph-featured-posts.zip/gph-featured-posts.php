<?php
/**
 * Plugin Name: GPH Featured Posts
 * Plugin URI: https://gopickhost.com
 * Description: A plugin to manage and display featured posts in a horizontal slider on the homepage. Designed for Blocksy, Genesis, Storefront, Astra, Generate and OceanWP theme.
 * Version: 1.0.0
 * Author: Johnthan
 * License: GPL v2 or later
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Main GPH Featured Posts Class
 */
class GPH_Featured_Posts {
    
    /**
     * Plugin version
     */
    const VERSION = '1.0.0';
    
    /**
     * Option name for storing featured post IDs
     */
    const OPTION_NAME = 'gph_featured_posts';
    
    /**
     * Flag to prevent multiple displays
     */
    private static $displayed = false;
    
    /**
     * Constructor
     */
    public function __construct() {
        add_action('init', array($this, 'init'));
    }
    
    /**
     * Initialize the plugin
     */
    public function init() {
        // Admin hooks
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_post_save_featured_posts', array($this, 'save_featured_posts'));
        add_action('admin_enqueue_scripts', array($this, 'admin_enqueue_scripts'));
        
        // Frontend hooks
        add_action('wp_enqueue_scripts', array($this, 'frontend_enqueue_scripts'));
        add_action('wp_head', array($this, 'add_featured_posts_styles'));
        add_action('wp_footer', array($this, 'add_featured_posts_script'));
        add_shortcode('gph_featured_posts', array($this, 'featured_posts_shortcode'));
        
        // Hook to display featured posts right after the header/navigation
        add_action('blocksy:after_header', array($this, 'display_featured_posts'), 10);
        add_action('genesis_after_header', array($this, 'display_featured_posts'), 10);
        add_action('storefront_before_content', array($this, 'display_featured_posts'), 10);
        add_action('astra_content_before', array($this, 'display_featured_posts'), 10);
        add_action('generate_before_content', array($this, 'display_featured_posts'), 10);
        add_action('ocean_before_content_wrap', array($this, 'display_featured_posts'), 10);
    }
    
    /**
     * Add admin menu page
     */
    public function add_admin_menu() {
        add_menu_page(
            'Featured Posts',           // Page title
            'Featured Posts',           // Menu title
            'manage_options',           // Capability
            'gph-featured-posts',       // Menu slug
            array($this, 'admin_page'), // Callback function
            'dashicons-star-filled',    // Icon
            30                          // Position
        );
    }
    
    /**
     * Display admin page
     */
    public function admin_page() {
        // Get current featured posts
        $featured_posts = get_option(self::OPTION_NAME, array());
        
        // Get all published posts
        $all_posts = get_posts(array(
            'post_type' => 'post',
            'post_status' => 'publish',
            'numberposts' => -1,
            'orderby' => 'date',
            'order' => 'DESC'
        ));
        
        ?>
        <div class="wrap">
            <h1>Featured Posts Management</h1>
            <p>Select posts to feature on your homepage. They will appear in the order you select them.</p>
            <p>GPH Featured Posts has designed to show slider on main page for Blocksy, Genesis, Storefront, Astra, Generate and OceanWP theme. You can always use shortcode to display in different theme/custom theme/posts/pages. Use [gph_featured_posts] anywhere.</p>
            
            <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" id="featured-posts-form">
                <?php wp_nonce_field('save_featured_posts_nonce', 'featured_posts_nonce'); ?>
                <input type="hidden" name="action" value="save_featured_posts">
                
                <div class="featured-posts-admin">
                    <div class="selected-posts-section">
                        <h2>Selected Featured Posts (Drag to reorder)</h2>
                        <div id="selected-posts" class="selected-posts-list">
                            <?php
                            // Display currently selected posts in order
                            foreach ($featured_posts as $post_id) {
                                $post = get_post($post_id);
                                if ($post) {
                                    $this->render_selected_post_item($post);
                                }
                            }
                            ?>
                        </div>
                    </div>
                    
                    <div class="available-posts-section">
                        <h2>Available Posts</h2>
                        <div class="posts-search">
                            <input type="text" id="posts-search" placeholder="Search posts...">
                        </div>
                        <div id="available-posts" class="available-posts-list">
                            <?php
                            foreach ($all_posts as $post) {
                                if (!in_array($post->ID, $featured_posts)) {
                                    $this->render_available_post_item($post);
                                }
                            }
                            ?>
                        </div>
                    </div>
                </div>
                
                <input type="hidden" id="featured-posts-order" name="featured_posts_order" value="<?php echo esc_attr(implode(',', $featured_posts)); ?>">
                
                <p class="submit">
                    <input type="submit" class="button-primary" value="Save Featured Posts">
                </p>
            </form>
        </div>
        <?php
    }
    
    /**
     * Render selected post item
     */
    private function render_selected_post_item($post) {
        $thumbnail = get_the_post_thumbnail($post->ID, 'thumbnail');
        ?>
        <div class="post-item selected-post" data-post-id="<?php echo $post->ID; ?>">
            <span class="dashicons dashicons-menu drag-handle"></span>
            <div class="post-thumbnail">
                <?php echo $thumbnail ? $thumbnail : '<div class="no-image">No Image</div>'; ?>
            </div>
            <div class="post-info">
                <strong><?php echo esc_html($post->post_title); ?></strong>
                <small><?php echo get_the_date('', $post); ?></small>
            </div>
            <button type="button" class="button remove-post" data-post-id="<?php echo $post->ID; ?>">Remove</button>
        </div>
        <?php
    }
    
    /**
     * Render available post item
     */
    private function render_available_post_item($post) {
        $thumbnail = get_the_post_thumbnail($post->ID, 'thumbnail');
        ?>
        <div class="post-item available-post" data-post-id="<?php echo $post->ID; ?>" data-title="<?php echo esc_attr(strtolower($post->post_title)); ?>">
            <div class="post-thumbnail">
                <?php echo $thumbnail ? $thumbnail : '<div class="no-image">No Image</div>'; ?>
            </div>
            <div class="post-info">
                <strong><?php echo esc_html($post->post_title); ?></strong>
                <small><?php echo get_the_date('', $post); ?></small>
            </div>
            <button type="button" class="button button-primary add-post" data-post-id="<?php echo $post->ID; ?>">Add to Featured</button>
        </div>
        <?php
    }
    
    /**
     * Save featured posts
     */
    public function save_featured_posts() {
        // Verify nonce
        if (!wp_verify_nonce($_POST['featured_posts_nonce'], 'save_featured_posts_nonce')) {
            wp_die('Security check failed');
        }
        
        // Check user permissions
        if (!current_user_can('manage_options')) {
            wp_die('Insufficient permissions');
        }
        
        // Get and sanitize the post order
        $featured_posts_order = sanitize_text_field($_POST['featured_posts_order']);
        $featured_posts = array();
        
        if (!empty($featured_posts_order)) {
            $post_ids = explode(',', $featured_posts_order);
            foreach ($post_ids as $post_id) {
                $post_id = intval($post_id);
                if ($post_id > 0 && get_post($post_id)) {
                    $featured_posts[] = $post_id;
                }
            }
        }
        
        // Save to options
        update_option(self::OPTION_NAME, $featured_posts);
        
        // Redirect back with success message
        wp_redirect(add_query_arg('message', 'saved', admin_url('admin.php?page=gph-featured-posts')));
        exit;
    }
    
    /**
     * Enqueue admin scripts and styles
     */
    public function admin_enqueue_scripts($hook) {
        if ($hook !== 'toplevel_page_gph-featured-posts') {
            return;
        }
        
        wp_enqueue_script('jquery-ui-sortable');
        wp_enqueue_script(
            'gph-featured-posts-admin',
            plugin_dir_url(__FILE__) . 'admin.js',
            array('jquery', 'jquery-ui-sortable'),
            self::VERSION,
            true
        );
        
        wp_enqueue_style(
            'gph-featured-posts-admin',
            plugin_dir_url(__FILE__) . 'admin.css',
            array(),
            self::VERSION
        );
    }
    
    /**
     * Enqueue frontend scripts and styles
     */
    public function frontend_enqueue_scripts() {
        wp_enqueue_style(
            'gph-featured-posts-frontend',
            plugin_dir_url(__FILE__) . 'frontend.css',
            array(),
            self::VERSION
        );
        
        wp_enqueue_script(
            'gph-featured-posts-frontend',
            plugin_dir_url(__FILE__) . 'frontend.js',
            array('jquery'),
            self::VERSION,
            true
        );
    }
    
    /**
     * Add featured posts styles in head
     */
    public function add_featured_posts_styles() {
        if (!is_home() && !is_front_page()) {
            return;
        }
        
        ?>
        <style>
        .gph-featured-posts-positioned {
            position: relative;
            z-index: 999;
            width: 100%;
            margin: 0 auto;
            clear: both;
        }
        </style>
        <?php
    }
    
    /**
     * Display featured posts (only once)
     */
    public function display_featured_posts() {
        // Only show on homepage/front page
        if (!is_home() && !is_front_page()) {
            return;
        }
        
        // Prevent multiple displays
        if (self::$displayed) {
            return;
        }
        
        $featured_post_ids = get_option(self::OPTION_NAME, array());
        if (empty($featured_post_ids)) {
            return;
        }
        
        self::$displayed = true;
        
        echo '<div class="gph-featured-posts-positioned">';
        echo $this->get_featured_posts_html();
        echo '</div>';
    }
    
    /**
     * Add featured posts script to footer (fallback for themes without proper hooks)
     */
    public function add_featured_posts_script() {
        // Only run on homepage/front page
        if (!is_home() && !is_front_page()) {
            return;
        }
        
        // Don't run if already displayed
        if (self::$displayed) {
            return;
        }
        
        $featured_post_ids = get_option(self::OPTION_NAME, array());
        if (empty($featured_post_ids)) {
            return;
        }
        
        $featured_posts_html = $this->get_featured_posts_html();
        $escaped_html = wp_json_encode($featured_posts_html);
        
        ?>
        <script type="text/javascript">
        document.addEventListener('DOMContentLoaded', function() {
            // Check if featured posts already exist
            if (document.querySelector('.gph-featured-posts-container')) {
                return;
            }
            
            var featuredPostsHtml = <?php echo $escaped_html; ?>;
            
            // Try to find the best insertion point (after header/navigation)
            var targetElement = null;
            var insertionPoint = null;
            
            // Try various selectors for finding the header/navigation
            var headerSelectors = [
                'header.site-header',
                '.site-header',
                'header',
                '.header',
                '.main-navigation',
                '.navigation',
                'nav.navbar',
                '.navbar',
                '#masthead',
                '.masthead'
            ];
            
            // Find the header/navigation element
            for (var i = 0; i < headerSelectors.length; i++) {
                var headerEl = document.querySelector(headerSelectors[i]);
                if (headerEl) {
                    targetElement = headerEl.parentNode;
                    insertionPoint = headerEl.nextSibling;
                    break;
                }
            }
            
            // If no header found, try to find main content area
            if (!targetElement) {
                var contentSelectors = [
                    'main',
                    '#main',
                    '.site-main',
                    '#content',
                    '.content',
                    '.main-content',
                    '.container',
                    '.wrap',
                    '.site-content'
                ];
                
                for (var i = 0; i < contentSelectors.length; i++) {
                    targetElement = document.querySelector(contentSelectors[i]);
                    if (targetElement) {
                        insertionPoint = targetElement.firstChild;
                        break;
                    }
                }
            }
            
            // Final fallback: insert at beginning of body
            if (!targetElement) {
                targetElement = document.body;
                insertionPoint = document.body.firstChild;
            }
            
            if (targetElement) {
                // Create container div
                var featuredDiv = document.createElement('div');
                featuredDiv.className = 'gph-featured-posts-positioned';
                featuredDiv.innerHTML = featuredPostsHtml;
                
                // Insert the element
                if (insertionPoint) {
                    targetElement.insertBefore(featuredDiv, insertionPoint);
                } else {
                    targetElement.appendChild(featuredDiv);
                }
                
                // Initialize slider
                if (typeof jQuery !== 'undefined') {
                    jQuery(document).trigger('gph_featured_posts_inserted');
                }
            }
        });
        </script>
        <?php
        
        // Mark as displayed to prevent running again
        self::$displayed = true;
    }
    
    /**
     * Shortcode for featured posts
     */
    public function featured_posts_shortcode($atts) {
        return $this->get_featured_posts_html();
    }
    
    /**
     * Get featured posts HTML
     */
    private function get_featured_posts_html() {
        $featured_post_ids = get_option(self::OPTION_NAME, array());
        
        if (empty($featured_post_ids)) {
            return '';
        }
        
        // $html = '<div class="gph-featured-posts-container">';
        // $html .= '<h2 class="featured-posts-title">Featured Posts</h2>';
        $html .= '<div class="gph-featured-posts-slider">';
        $html .= '<div class="featured-posts-wrapper">';
        
        foreach ($featured_post_ids as $post_id) {
            $post = get_post($post_id);
            if (!$post) {
                continue;
            }
            
            $thumbnail = get_the_post_thumbnail($post_id, 'medium');
            $permalink = get_permalink($post_id);
            $title = get_the_title($post_id);
            $excerpt = get_the_excerpt($post_id);
            
            $html .= '<div class="featured-post-slide">';
            $html .= '<a href="' . esc_url($permalink) . '" class="featured-post-link">';
            
            if ($thumbnail) {
                $html .= '<div class="featured-post-image">' . $thumbnail . '</div>';
            } else {
                $html .= '<div class="featured-post-image no-image"><span>No Image</span></div>';
            }
            
            $html .= '<div class="featured-post-content">';
            $html .= '<h3 class="featured-post-title">' . esc_html($title) . '</h3>';
            if ($excerpt) {
                $html .= '<p class="featured-post-excerpt">' . esc_html($excerpt) . '</p>';
            }
            $html .= '</div>'; // .featured-post-content
            $html .= '</a>'; // .featured-post-link
            $html .= '</div>'; // .featured-post-slide
        }
        
        $html .= '</div>'; // .featured-posts-wrapper
        $html .= '<button class="slider-nav prev" data-direction="prev">&lt;</button>';
        $html .= '<button class="slider-nav next" data-direction="next">&gt;</button>';
        $html .= '</div>'; // .gph-featured-posts-slider
        // $html .= '</div>'; // .gph-featured-posts-container
        
        return $html;
    }
}

// Initialize the plugin
new GPH_Featured_Posts();

/**
 * Plugin activation hook
 */
register_activation_hook(__FILE__, 'gph_featured_posts_activate');
function gph_featured_posts_activate() {
    // Create default option if it doesn't exist
    if (get_option(GPH_Featured_Posts::OPTION_NAME) === false) {
        add_option(GPH_Featured_Posts::OPTION_NAME, array());
    }
}

/**
 * Plugin deactivation hook
 */
register_deactivation_hook(__FILE__, 'gph_featured_posts_deactivate');
function gph_featured_posts_deactivate() {
    // Clean up if needed
}

/**
 * Plugin uninstall hook
 */
register_uninstall_hook(__FILE__, 'gph_featured_posts_uninstall');
function gph_featured_posts_uninstall() {
    // Remove the option when plugin is uninstalled
    delete_option(GPH_Featured_Posts::OPTION_NAME);
}